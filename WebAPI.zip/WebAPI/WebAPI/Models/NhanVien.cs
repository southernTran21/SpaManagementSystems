﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class NhanVien
    {
        public int id;
        public string idAccount;
        public string Ten;
        public int idChucVu;
        public string DienThoai;
        public string NgayBatDau;
        public int TinhTrang;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class ChucVu
    {
        public int id;
        public string TenChucVu;
        public float HeSoLuong;
    }
}
